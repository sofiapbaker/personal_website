# This R script is to run the Phillips-perron unit root test on the urban/rural/national series
# and the oil price. 
# - I will run the test on log price series, and first difference of log price series
# - I will linearly detrend the series themselves before testing, and will demean the differenced series
# - I will use Case 4 critical values for series themselves, and case 2 for differenced series

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)
library(tseries)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

#---------------------- Create log prices and their first diff --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), ~log(.), .names = "log_{col}"))

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))

                                          
#---------------------- Run tests --------------------------------------
data <- diesel; rm(diesel)

## log_oil 
t <- 1:nrow(data)
data <- cbind(data,t)
detrend.reg <- lm(log_oil~t,data=data)
summary(detrend.reg)

#get residuals
log_oil_detrended <- detrend.reg$residuals

# PP test 
test_log_oil <- pp.test(log_oil_detrended, alternative="stationary", type="Z(alpha)")
test_log_oil

## diff_log_oil
# demean diff_log_oil
diff_log_oil_demeaned <- data$diff_log_oil - mean(data$diff_log_oil, na.rm=T)
diff_log_oil_demeaned <- diff_log_oil_demeaned[-1]

# PP test 
test_diff_log_oil <- pp.test(diff_log_oil_demeaned, alternative="stationary", type="Z(alpha)")
test_diff_log_oil

## log_national
detrend.reg <- lm(log_national~t,data=data)
summary(detrend.reg)

#get residuals
log_national_detrended <- detrend.reg$residuals

# PP test 
test_log_national <- pp.test(log_national_detrended, alternative="stationary", type="Z(alpha)")
test_log_national 

## diff_log_national
# demean diff_log_national
diff_log_national_demeaned <- data$diff_log_national - mean(data$diff_log_national, na.rm=T)
diff_log_national_demeaned <- diff_log_national_demeaned[-1]

# PP test 
test_diff_log_national <- pp.test(diff_log_national_demeaned, alternative="stationary", type="Z(alpha)")
test_diff_log_national

## log_rural
detrend.reg <- lm(log_rural~t,data=data)
summary(detrend.reg)

#get residuals
log_rural_detrended <- detrend.reg$residuals

# PP test 
test_log_rural <- pp.test(log_rural_detrended, alternative="stationary", type="Z(alpha)")
test_log_rural 

## diff_log_rural
# demean diff_log_rural
diff_log_rural_demeaned <- data$diff_log_rural - mean(data$diff_log_rural, na.rm=T)
diff_log_rural_demeaned <- diff_log_rural_demeaned[-1]

# PP test 
test_diff_log_rural <- pp.test(diff_log_rural_demeaned, alternative="stationary", type="Z(alpha)")
test_diff_log_rural

## log_urban
detrend.reg <- lm(log_urban~t,data=data)
summary(detrend.reg)

#get residuals
log_urban_detrended <- detrend.reg$residuals

# PP test 
test_log_urban <- pp.test(log_urban_detrended, alternative="stationary", type="Z(alpha)")
test_log_urban

## diff_log_urban
# demean diff_log_urban
diff_log_urban_demeaned <- data$diff_log_urban - mean(data$diff_log_urban, na.rm=T)
diff_log_urban_demeaned <- diff_log_urban_demeaned[-1]

# PP test 
test_diff_log_urban <- pp.test(diff_log_urban_demeaned, alternative="stationary", type="Z(alpha)")
test_diff_log_urban

