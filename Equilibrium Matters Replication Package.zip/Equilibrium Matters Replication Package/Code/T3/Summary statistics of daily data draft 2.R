### This R script is to calculate summary statistics for the daily data used in the Bachmeier-Griffin model
## Get the following:
# - # of stations, generated from "Creating daily aggregated series 2.R"
# - mean and variance of all variables
# - split the summ stats by urban/rural
# - also split by positive/negative changes

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load number of stations --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
n_stations <- read.csv("n_stations_rural_urban.csv")
n_stations[,"X"] <- NULL

#---------------------- Load data --------------------------------------
load("two_group_prices_daily_with_oil.RData")

#---------------------- Prepare Data --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), ~log(.), .names = "log_{col}"))
diesel <- dplyr::select(diesel, -oil,-national,-rural,-urban)

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))

# Run regressions of diesel on oil to get ect estimates
data <- diesel; rm(diesel)

LR_national <- lm(log_national~log_oil, data=data) 
LR_urban <- lm(log_urban~log_oil, data=data)
LR_rural <- lm(log_rural~log_oil, data=data)

summary(LR_national)
summary(LR_urban)
summary(LR_rural)

# get residuals (error correction term)
data$z_national <- summary(LR_national)$residuals
data$z_urban <- summary(LR_urban)$residuals
data$z_rural <- summary(LR_rural)$residuals

colnames(data) <- gsub("diff_log_","D.",colnames(data))

# multiply log differenced series by 100 so they are in percentage terms
data <- data %>% mutate(across(starts_with("D."), ~.*100))

Table <- matrix(NA,4,9)
row.names(Table) <- c("national","urban","rural","oil")
colnames(Table) <- c("n_stations","mean_pt","var_pt","mean_D.pt","var_D.pt",
                     "mean_D.pt.plus","var_D.pt.plus","mean_D.pt.minus","var_D.pt.minus")

Table["national","n_stations"] <- sum(n_stations[1,"n"],n_stations[2,"n"])
Table["urban","n_stations"] <- n_stations[1,"n"]
Table["rural","n_stations"] <- n_stations[2,"n"]

pt <- select(data,log_national,log_urban,log_rural,log_oil)
Table[,"mean_pt"] <- apply(pt,2,mean)
Table[,"var_pt"] <- apply(pt,2,var)

D.pt <- select(data,D.national,D.urban,D.rural,D.oil)
Table[,"mean_D.pt"] <- apply(D.pt,2,mean,na.rm=T)
Table[,"var_D.pt"] <- apply(D.pt,2,var,na.rm=T)

D.national.plus <- filter(D.pt,D.national>0)$D.national
D.national.minus <- filter(D.pt,D.national<=0)$D.national
D.urban.plus <- filter(D.pt,D.urban>0)$D.urban
D.urban.minus <- filter(D.pt,D.urban<=0)$D.urban
D.rural.plus <- filter(D.pt,D.rural>0)$D.rural
D.rural.minus <- filter(D.pt,D.rural<=0)$D.rural
D.oil.plus <- filter(D.pt,D.oil>0)$D.oil
D.oil.minus <- filter(D.pt,D.oil<=0)$D.oil

D.pt.plus <- list(national=D.national.plus, urban=D.urban.plus,
                                       rural=D.rural.plus, oil=D.oil.plus)
D.pt.minus <- list(national=D.national.minus, urban=D.urban.minus,
                                        rural=D.rural.minus, oil=D.oil.minus)

Table[,"mean_D.pt.plus"] <- sapply(D.pt.plus,mean)
Table[,"var_D.pt.plus"] <- sapply(D.pt.plus,var)

Table[,"mean_D.pt.minus"] <- sapply(D.pt.minus,mean)
Table[,"var_D.pt.minus"] <- sapply(D.pt.minus,var)

setwd("/Users/olgabaker/Desktop/Miller work/ORGANIZING DATA/Summary statistics of daily data")
write.csv(Table,'summ_stats_table.csv')
