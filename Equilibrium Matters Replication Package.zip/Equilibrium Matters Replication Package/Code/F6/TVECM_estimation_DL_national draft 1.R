### This R script calculates the TVECM with diesel on the LHS of the LR reg and
### six lags on oil/diesel in both regimes, using a one-step estimation procedure:
### - Grid search around the initial beta (cointegrating slope) from OLS.
### - For each candidate beta, partition the data on the sign of the lagged
###   cointegrating residual (threshold fixed at u_{t-1} = 0).
### - Estimate the remaining (regime-specific) parameters for each beta.
### - Compute the total SSR for every iteration.
### - Select the beta / parameter set that minimises the total SSR.

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT model is run with different lags by regime 
#/Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/TVECM_estimation draft 3.R

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

# define group and lags
group <- "national"

diesel <- select(diesel,Date,all_of(group),oil)

diesel <- diesel %>% mutate(across(-Date, ~log(.), .names = "log_{col}"))
diesel <- dplyr::select(diesel, -oil,-all_of(group))

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))
data <- diesel; rm(diesel)
colnames(data) <- gsub(group,"diesel", colnames(data))

### =====================================================================
### TVECM estimation
###
### Long run (cointegrating regression):
###     d_t = a + b o_t + u_t
###
### Short run (threshold error-correction, single equation for Δd_t):
###     Δd_t = Σ_{i=1}^{lo_R} πR_i^o Δo_{t-i}
###          + Σ_{i=1}^{ld_R} πR_i^d Δd_{t-i}
###          + δ_R û_{t-1} + ε_Rt
###   with   R = L (lower) if û_{t-1} <= 0
###          R = U (upper) if û_{t-1} >  0
###
### d_t = log_diesel, o_t = log_oil. The threshold is fixed at 0, so every
### coefficient (the lo_R + ld_R lags and the EC term) is estimated separately in each
### regime by running two OLS regressions on the partitioned sample.
### =====================================================================

## ---- 0. Estimation settings ------------------------------------------
lo_L  <- 5      # lags on Δo and Δd in each regime
ld_L <- 5
lo_U <- 6
ld_U <- 6

grid_n     <- 401    # number of candidate beta values in the grid
grid_half  <- 0.10   # half-width of the beta grid: search over b0 ± grid_half
                     #   -> if the selected beta lands on a grid boundary
                     #      (flagged below), widen grid_half and re-run.

# The short-run equation has no constant, exactly as written: each regime is
# fit as a regression through the origin.

## ---- 1. Series and a simple row-shift lag ----------------------------
d   <- data$log_diesel          # d_t
o   <- data$log_oil             # o_t
dd  <- data$diff_log_diesel     # Δd_t  (row 1 is NA from differencing)
do_ <- data$diff_log_oil        # Δo_t  (row 1 is NA from differencing)

# Row-shift lag (treats consecutive rows as consecutive trading days, which is
# the standard convention for daily price series with weekend/holiday gaps).
lagv <- function(x, k) c(rep(NA, k), head(x, -k))

## ---- 2. Initial cointegrating regression (OLS) -----------------------
lr0   <- lm(d ~ o)                                        # d_t = a + b o_t + u_t
b0    <- unname(coef(lr0)["o"])
a0    <- unname(coef(lr0)["(Intercept)"])
se_b0 <- summary(lr0)$coefficients["o", "Std. Error"]

## ---- 3. Fit the TVECM for a single candidate beta --------------------
## For each beta the intercept is re-set to the conditional-OLS value
##     a(b) = mean(d) - b*mean(o)
## so the residual u_t = d_t - a(b) - b o_t always has mean zero and the
## threshold at 0 keeps its interpretation (diesel above vs. below the
## long-run relation). To instead hold the intercept at the initial OLS
## value, replace the a line with:  a <- a0

fit_tvecm <- function(b) {
  a  <- mean(d) - b * mean(o)          # conditional intercept
  uu <- d - a - b * o                  # cointegrating residual u_t (levels)
  
  Lmax <- max(lo_L, ld_L, lo_U, ld_U)
  
  Xo <- sapply(seq_len(Lmax), function(k) lagv(do_, k))   # Δo_{t-1..Lmax}
  Xd <- sapply(seq_len(Lmax), function(k) lagv(dd,  k))   # Δd_{t-1..Lmax}
  colnames(Xo) <- paste0("do_l", seq_len(Lmax))
  colnames(Xd) <- paste0("dd_l", seq_len(Lmax))
  df <- data.frame(y = dd, ecm = lagv(uu, 1), Xo, Xd)
  df <- df[complete.cases(df), ]       # common window: drops first 1 + Lmax rows
  
  low <- df$ecm <= 0                   # regime split at û_{t-1} = 0
  
  # Regime-specific right-hand sides (no constant); each lm uses only the
  # lag columns named in its own formula, ignoring the deeper ones in df.
  rhs_L <- c(paste0("do_l", seq_len(lo_L)), paste0("dd_l", seq_len(ld_L)), "ecm")
  rhs_U <- c(paste0("do_l", seq_len(lo_U)), paste0("dd_l", seq_len(ld_U)), "ecm")
  form_L <- as.formula(paste("y ~ 0 +", paste(rhs_L, collapse = " + ")))
  form_U <- as.formula(paste("y ~ 0 +", paste(rhs_U, collapse = " + ")))
  
  mL <- lm(form_L, data = df[low,  ])  # lower regime  (û_{t-1} <= 0)
  mU <- lm(form_U, data = df[!low, ])  # upper regime  (û_{t-1} >  0)
  
  ssr <- sum(resid(mL)^2) + sum(resid(mU)^2)
  list(b = b, a = a, ssr = ssr, mL = mL, mU = mU,
       nL = sum(low), nU = sum(!low), n = nrow(df),
       lo_L = lo_L, ld_L = ld_L, lo_U = lo_U, ld_U = ld_U)
}

## ---- 4. Grid search over beta ----------------------------------------
grid <- seq(b0 - grid_half, b0 + grid_half, length.out = grid_n)
ssrs <- vapply(grid, function(b) fit_tvecm(b)$ssr, numeric(1))

b_hat <- grid[which.min(ssrs)]
best  <- fit_tvecm(b_hat)             # final fit at the SSR-minimising beta

## ---- 5. Diagnostics on the search ------------------------------------
on_boundary <- (which.min(ssrs) %in% c(1L, grid_n))
if (on_boundary)
  warning("Selected beta is on a grid boundary -- widen 'grid_half' and re-run.")
if (best$nL <= lo_L + ld_L + 1)
  warning("Lower regime has too few observations relative to the number of parameters.")
if (best$nU <= lo_U + ld_U + 1)
  warning("Upper regime has too few observations relative to the number of parameters.")
## ---- 6. Report -------------------------------------------------------
cat("=====================================================================\n")
cat(sprintf(" TVECM (threshold = 0 on lagged EC term; %d = lo_L, %d = ld_L, %d = lo_U, %d = ld_U \n",lo_L,ld_L,lo_U,ld_U))
cat("=====================================================================\n")
cat(sprintf("Initial OLS slope  b0 = %.4f  (SE %.4f)\n", b0, se_b0))
cat(sprintf("Initial OLS intcpt a0 = %.4f\n", a0))
cat(sprintf("Grid: [%.4f, %.4f] with %d points; argmin interior = %s\n",
            min(grid), max(grid), grid_n, !on_boundary))
cat(sprintf("Selected slope     b  = %.4f\n", best$b))
cat(sprintf("Implied intercept  a  = %.4f\n", best$a))
cat(sprintf("Obs used            n = %d   (lower %d / upper %d)\n",
            best$n, best$nL, best$nU))
cat(sprintf("Total SSR             = %.6f\n\n", best$ssr))

cat("---- Lower regime  (u_hat_{t-1} <= 0) --------------------------------\n")
print(summary(best$mL)$coefficients)
cat("\n---- Upper regime  (u_hat_{t-1} >  0) --------------------------------\n")
print(summary(best$mU)$coefficients)

## Tidy combined coefficient table (regime, term, estimate, se, t, p)
tidy_reg <- function(m, regime) {
  s <- summary(m)$coefficients
  data.frame(regime = regime, term = rownames(s),
             estimate = s[, 1], se = s[, 2], t = s[, 3], p = s[, 4],
             row.names = NULL)
}
tvecm_coefs <- rbind(tidy_reg(best$mL, "lower"), tidy_reg(best$mU, "upper"))

## Objects kept for downstream use:
##   best$b, best$a        : selected cointegrating vector (1, -b) with intercept a
##   best$mL, best$mU      : fitted regime regressions (lm objects)
##   tvecm_coefs           : tidy coefficient table for both regimes
##   grid, ssrs            : SSR profile over the beta grid

# save output
setwd('/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT')
save.image(file='TVECM_estimation_DL_national draft 1.RData')

## ---- 7. (optional) SSR profile plot ----------------------------------
# plot(grid, ssrs, type = "l", xlab = expression(beta), ylab = "total SSR",
#      main = "SSR profile over the cointegrating slope")
# abline(v = b_hat, lty = 2)
