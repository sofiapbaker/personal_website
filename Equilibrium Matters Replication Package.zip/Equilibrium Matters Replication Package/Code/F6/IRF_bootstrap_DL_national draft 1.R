### This R script is to make bootstrap confidence intervals for the one-stage-estimation TVECM IRF with daily data

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT model is run with different lags by regime
## /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/IRF_bootstrap draft 3.R

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
load("IRF_estimation_DL_national draft 1.RData")
pos_IRF_hat <- IRF_positive
neg_IRF_hat <- IRF_negative

# Bootstrap reps ---------------------------------------------------------------------------------------------------------
R <- 999
pos_IRF_matrix <- matrix(NA,length(pos_IRF_hat),R+1)
pos_IRF_matrix[,R+1] <- pos_IRF_hat

neg_IRF_matrix <- matrix(NA,length(neg_IRF_hat),R+1)
neg_IRF_matrix[,R+1] <- neg_IRF_hat

epshat_L <- summary(best$mL)$residuals
epshat_U <- summary(best$mU)$residuals

# get lagged differences 
for(i in 1:max_lag){
  name <- paste0("l",i,".{col}")
  data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=i),.names = name))
}
colnames(data) <- gsub("diff_log_","D.",colnames(data))

# get first lag of oil and diesel
data <- data %>% mutate(l1.o=lag(log_oil),l1.d=lag(log_diesel))

# crop sample
data <- data[complete.cases(data),]

# Bootstrap function ---------------------------------------------------------------------------------------------------------
bootstrap <- function(r){
  boot <- data 
  
  # PART B: Resample from residuals @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  set.seed(r)
  
  epstil_L <- sample(epshat_L,length(epshat_L),replace=T)
  epstil_U <- sample(epshat_U,length(epshat_U),replace=T)
  
  # PART C: get D.dtil @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  j <- 1
  k <- 1
  boot$D.dtil <- NA
  for(t in 1:nrow(boot)){
    if(boot$l1.d[t]-ahat-bhat*boot$l1.o[t] <= 0){
      # Lower regime
      summation_piL_o <- rep(NA, lo_L)
      for(i in 1:lo_L){
        summation_piL_o[i] <- piL_o_hat[paste0("l",i)] * boot[[paste0("l",i,".D.oil")]][t]
      }
      summation_piL_d <- rep(NA, ld_L)
      for(i in 1:ld_L){
        summation_piL_d[i] <- piL_d_hat[paste0("l",i)] * boot[[paste0("l",i,".D.diesel")]][t]
      }
      boot$D.dtil[t] <- sum(summation_piL_o) + sum(summation_piL_d) +
        deltaL_hat * (boot$l1.d[t]-ahat-bhat*boot$l1.o[t]) + epstil_L[j]
      j <- j+1
    } else {
      # Upper regime
      summation_piU_o <- rep(NA, lo_U)
      for(i in 1:lo_U){
        summation_piU_o[i] <- piU_o_hat[paste0("l",i)] * boot[[paste0("l",i,".D.oil")]][t]
      }
      summation_piU_d <- rep(NA, ld_U)
      for(i in 1:ld_U){
        summation_piU_d[i] <- piU_d_hat[paste0("l",i)] * boot[[paste0("l",i,".D.diesel")]][t]
      }
      boot$D.dtil[t] <- sum(summation_piU_o) + sum(summation_piU_d) +
        deltaU_hat * (boot$l1.d[t]-ahat-bhat*boot$l1.o[t]) + epstil_U[k]
      k <- k+1
    }
  }
  
  # PART D: Get a_til,b_til,pi_til,delta_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  # Edit fit.tvecm so y is D.dtil
  fit_D.dtil <- function(b) {
    a  <- mean(d) - b * mean(o)          # conditional intercept
    uu <- d - a - b * o                  # cointegrating residual u_t (levels)
    
    Lmax <- max(lo_L, ld_L, lo_U, ld_U)
    
    Xo <- sapply(seq_len(Lmax), function(k) lagv(do_, k))   # Δo_{t-1..Lmax}
    Xd <- sapply(seq_len(Lmax), function(k) lagv(dd,  k))   # Δd_{t-1..Lmax}
    colnames(Xo) <- paste0("do_l", seq_len(Lmax))
    colnames(Xd) <- paste0("dd_l", seq_len(Lmax))
    D.dtil <- c(rep(NA,length(d)-length(boot$D.dtil)),boot$D.dtil)
    df <- data.frame(y = D.dtil, ecm = lagv(uu, 1), Xo, Xd)
    df <- df[complete.cases(df), ]       # common window: drops first 1 + Lmax rows
    
    low <- df$ecm <= 0                   # regime split at û_{t-1} = 0
    
    # Regime-specific right-hand sides (no constant); each lm uses only the
    # lag columns named in its own formula, ignoring the deeper ones in df.
    rhs_L <- c(paste0("do_l", seq_len(lo_L)), paste0("dd_l", seq_len(ld_L)), "ecm")
    rhs_U <- c(paste0("do_l", seq_len(lo_U)), paste0("dd_l", seq_len(ld_U)), "ecm")
    form_L <- as.formula(paste("y ~ 0 +", paste(rhs_L, collapse = " + ")))
    form_U <- as.formula(paste("y ~ 0 +", paste(rhs_U, collapse = " + ")))
    
    mL <- lm(form_L, data = df[low,  ])  # lower regime  (û_{t-1} <= 0)
    mU <- lm(form_U, data = df[!low, ])  # upper regime  (û_{t-1} >  0)
    
    ssr <- sum(resid(mL)^2) + sum(resid(mU)^2)
    list(b = b, a = a, ssr = ssr, mL = mL, mU = mU,
         nL = sum(low), nU = sum(!low), n = nrow(df),
         lo_L = lo_L, ld_L = ld_L, lo_U = lo_U, ld_U = ld_U)
  }
  
  
  # Grid search over beta 
  ssrs_D.dtil <- vapply(grid, function(b) fit_D.dtil(b)$ssr, numeric(1))
  
  b_til <- grid[which.min(ssrs_D.dtil)]
  best_til  <- fit_D.dtil(b_til)             # final fit at the SSR-minimising beta
  
  # Code the parameters ############################################
  atil <- best_til$a
  btil <- best_til$b
  
  # Lower regime
  coefs.lower_til <- coef(best_til$mL)
  deltaL_til <- coefs.lower_til["ecm"]
  
  piL_o_til <- coefs.lower_til[startsWith(names(coefs.lower_til),"do_")]
  names(piL_o_til) <- gsub("do_","",names(piL_o_til))
  
  piL_d_til <- coefs.lower_til[startsWith(names(coefs.lower_til),"dd_")]
  names(piL_d_til) <- gsub("dd_","",names(piL_d_til))

  # upper regime
  coefs.upper_til <- coef(best_til$mU)
  deltaU_til <- coefs.upper_til["ecm"]
  
  piU_o_til <- coefs.upper_til[startsWith(names(coefs.upper_til),"do_")]
  names(piU_o_til) <- gsub("do_","",names(piU_o_til))
  
  piU_d_til <- coefs.upper_til[startsWith(names(coefs.upper_til),"dd_")]
  names(piU_d_til) <- gsub("dd_","",names(piU_d_til))
  
  # PART E: Get pos_IRF_til and neg_IRF_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  pos_IRF_til <- IRF.function(0.01,atil,btil,piL_o_til,piL_d_til,
                          piU_o_til,piU_d_til,deltaL_til,deltaU_til)
  neg_IRF_til <- IRF.function(-0.01,atil,btil,piL_o_til,piL_d_til,
                              piU_o_til,piU_d_til,deltaL_til,deltaU_til)
  
  list(pos_IRF_til = pos_IRF_til, neg_IRF_til = neg_IRF_til)
}

# run bootstrap
start.time <- Sys.time()
for(r in 1:R){
  iteration <- bootstrap(r)
  pos_IRF_matrix[,r] <- iteration$pos_IRF_til
  neg_IRF_matrix[,r] <- iteration$neg_IRF_til
  print(r)
}
duration <- Sys.time() - start.time
#---------------------- Save bootstrap output --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")

#save.image(file='IRF_bootstrap_DL_national draft 1.RData')
load('IRF_bootstrap_DL_national draft 1.RData') # use to load the R objects without running the above code

# PART F: Repeat B-E a total of R=999 times and get CIs for IRF_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

# use the quantile() function with type=6, as Dave does in his second year textbook
quantile(pos_IRF_matrix[2,],probs=0.025,type=6)
quantile(pos_IRF_matrix[2,],probs=0.975,type=6)

# Positive CI
pos_CI_lower <- apply(pos_IRF_matrix, 1, quantile, probs=.025,type=6)
pos_CI_upper <- apply(pos_IRF_matrix, 1, quantile, probs=0.975,type=6)
pos_CI_lower<=pos_CI_upper

# Negative CI
neg_CI_lower <- apply(neg_IRF_matrix, 1, quantile, probs=.025,type=6)
neg_CI_upper <- apply(neg_IRF_matrix, 1, quantile, probs=0.975,type=6)
neg_CI_lower<=neg_CI_upper

CI <- cbind(n_days_after_shock=0:n_out,pos_CI_lower=pos_CI_lower,pos_CI_upper=pos_CI_upper,
            neg_CI_lower=-neg_CI_lower,neg_CI_upper=-neg_CI_upper)
write.csv(CI, "IRF_bootstrap_DL_national draft 1.csv",row.names=F)
  
