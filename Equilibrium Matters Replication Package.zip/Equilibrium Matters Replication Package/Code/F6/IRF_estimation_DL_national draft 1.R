### This R script is to calculate an asymmetric IRF using the method from Goodwin and Piggott (2001)
### choosing the starting history as equilibrium, where the diesel price is set to sample average

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT model is run with different lags by regime
## /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/IRF_estimation draft 2.R

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load TVECM output --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
load("TVECM_estimation_DL_national draft 1.RData")

# define group and lags
group <- "national"

#------------------------- Define functions ---------------------------
# Set fixed values for functions
n_out <- 40
d0 <- mean(data$log_diesel)
max_lag <- max(lo_L,lo_U,ld_L,ld_U)

IRF.function <- function(shock,a,b,piL_o,piL_d,piU_o,piU_d,deltaL,deltaU){
  diesel_series_given_oil <- function(oil_series){
    
    # initialization
    d <- rep(NA,max_lag+n_out+2)
    d[1:(max_lag+1)] <- d0
    o <- oil_series
    
    # predict diesel based on oil
    # note that diff(o) does not put an NA at start of the vector so diff(o)[t] = o[t+1]-o[t]
    for(t in (max_lag+1):(n_out+max_lag+1)){
      summation_piL_o <- rep(NA, lo_L)
      for(i in 1:lo_L){
        summation_piL_o[i] <- piL_o[paste0("l",i)]*diff(o)[t-i]
      }
      summation_piL_d <- rep(NA, ld_L)
      for(i in 1:ld_L){
        summation_piL_d[i] <- piL_d[paste0("l",i)]*diff(d)[t-i]
      }
      summation_piU_o <- rep(NA, lo_U)
      for(i in 1:lo_U){
        summation_piU_o[i] <- piU_o[paste0("l",i)]*diff(o)[t-i]
      }
      summation_piU_d <- rep(NA, ld_U)
      for(i in 1:ld_U){
        summation_piU_d[i] <- piU_d[paste0("l",i)]*diff(d)[t-i]
      }
      
      d[t+1] <- d[t-1+1] + if(d[t-1+1]-a-b*o[t-1+1]<=0){
        deltaL*(d[t-1+1]-a-b*o[t-1+1]) + sum(summation_piL_o) + sum(summation_piL_d)} 
      else {
        deltaU*(d[t-1+1]-a-b*o[t-1+1]) + sum(summation_piU_o) + sum(summation_piU_d) 
      }
    }
    
    # finalization 
    d <- d[-1:-(max_lag+1)]
    
    return(d)
  }
  
  o0 <- (-a/b) + (1/b)*d0; names(o0) <- NULL
  oil_no_shock <- rep(o0, 1000)
  d_no_shock <- diesel_series_given_oil(oil_no_shock)
  
  oil_with_shock <- c(rep(o0,max_lag+1),rep(o0+shock, 1000-(max_lag+1)))
  d_with_shock <- diesel_series_given_oil(oil_with_shock)
  IRF <- 100*(d_with_shock - d_no_shock) 
  return(IRF)
}

# Code the parameters ############################################
ahat <- best$a
bhat <- best$b

# Lower regime
coefs.lower <- coef(best$mL)
deltaL_hat <- coefs.lower["ecm"]

piL_o_hat <- coefs.lower[startsWith(names(coefs.lower),"do_")]
names(piL_o_hat) <- gsub("do_","",names(piL_o_hat))

piL_d_hat <- coefs.lower[startsWith(names(coefs.lower),"dd_")]
names(piL_d_hat) <- gsub("dd_","",names(piL_d_hat))

# upper regime
coefs.upper <- coef(best$mU)
deltaU_hat <- coefs.upper["ecm"]

piU_o_hat <- coefs.upper[startsWith(names(coefs.upper),"do_")]
names(piU_o_hat) <- gsub("do_","",names(piU_o_hat))

piU_d_hat <- coefs.upper[startsWith(names(coefs.upper),"dd_")]
names(piU_d_hat) <- gsub("dd_","",names(piU_d_hat))


IRF_positive <- IRF.function(0.01,ahat,bhat,piL_o_hat,piL_d_hat,
                                 piU_o_hat,piU_d_hat,deltaL_hat,deltaU_hat)

IRF_negative <- IRF.function(-0.01,ahat,bhat,piL_o_hat,piL_d_hat,
                                      piU_o_hat,piU_d_hat,deltaL_hat,deltaU_hat)
# 7) Export data for a graph ########################################################
graph_data <- cbind(n_days_after_shock=0:n_out,
                    Negative=-IRF_negative,Positive=IRF_positive)

setwd('/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT')
file <- paste0("IRF_",group,"_daily_DL.csv")
write.csv(graph_data, file, row.names=F) 
save.image(file='IRF_estimation_DL_national draft 1.RData')
