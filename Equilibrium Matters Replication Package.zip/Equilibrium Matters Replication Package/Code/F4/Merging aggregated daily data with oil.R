# This R script is to prepare the daily price series for the TVECM for the version run with daily data.
# need daily urban/rural/national data and daily oil price/exchange rate

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load diesel data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("aggregate_prices_daily.RData")
diesel <- aggregate_prices; rm(aggregate_prices)

#---------------------- Load oil data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/oil price data")
load("raw_brent_prices.RData")

# crop dates to when diesel price is available
oil <- filter(oil, Date>=min(diesel$Date) &
                Date<=max(diesel$Date))

# rename series
oil <- rename(oil, oil_usd=Price)

#---------------------- Load exchange rate data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Running Gautier 2023 Replication Package/Raw Data")

# exchange rate gives number of usd per euro:
exchange_rate <- read.csv("eurusd_herokuapp.csv", sep=";")
exchange_rate$Date <- as.Date(exchange_rate$date, format = "%m/%d/%Y")
exchange_rate$date <- NULL

# merge into oil data
oil <- left_join(oil, exchange_rate)

# convert oil price to euros
oil$oil_eur <- oil$oil_usd/oil$eurusd
summary(oil) # 21 days where exchange rate was unavailable 
rm(exchange_rate)

oil <- select(oil, Date, oil=oil_eur)

#---------------------- Merge diesel and oil data --------------------------------------
diesel <- left_join(diesel,oil)
summary(diesel)

# drop days where oil price is not available
diesel <- filter(diesel, complete.cases(diesel))

# Export
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
save(diesel, file = "two_group_prices_daily_with_oil.RData")
write.csv(diesel, "two_group_prices_daily_with_oil.csv", row.names = F)
