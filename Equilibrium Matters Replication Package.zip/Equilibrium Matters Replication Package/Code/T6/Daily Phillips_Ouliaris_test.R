# This R script is to run the Phillips-ouliaris cointegration test on the urban/rural/national series
# with the oil price. 
# - I will run the test on log price series

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)
library(urca)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

#---------------------- Create log prices and their first diff --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), 
                                                 ~log(.), .names = "log_{col}"))

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))

                                          
#---------------------- Run tests --------------------------------------
data <- diesel
rm(diesel)

po_national <- ca.po(select(data,log_national,log_oil), demean="constant", type="Pu")
po_rural <- ca.po(select(data,log_rural,log_oil), demean="constant", type="Pu")
po_urban <- ca.po(select(data,log_urban,log_oil), demean="constant", type="Pu")

po_national
po_rural
po_urban
