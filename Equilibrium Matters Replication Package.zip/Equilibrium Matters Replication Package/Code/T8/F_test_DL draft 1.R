### This R script is to run an F-test to see if the TVECM fit is better when I allow for asymmetry based on the sign of the
### oil price change

### Model 4: Regular TVECM
### Model 5: TVECM with asymmetry based on sign of oil price change

### Modifying the below so models are estimated with lags by regime
# /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/F_test draft 1.R
#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load TVECM output --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
load("TVECM_estimation_DL_national draft 1.RData")

#------------------------- Run Model 5 ---------------------------

### =====================================================================
### fit_oil_asym : TVECM with sign-asymmetric oil pass-through
###
###  Δd_t = Σ_{i=1}^{q_R} ( π_Ri^{o+} Δo⁺_{t-i} + π_Ri^{o-} Δo⁻_{t-i} )
###       + Σ_{i=1}^{s_R} π_Ri^d Δd_{t-i} + δ_R (d_{t-1}-a-b*o_{t-1}) + ε_Rt
###
###   R = L if d_{t-1}-a-b*o_{t-1} <= 0 ,  R = U if d_{t-1}-a-b*o_{t-1} > 0
###   Δo⁺_{t-i} = max{Δo_{t-i}, 0}      Δo⁻_{t-i} = min{Δo_{t-i}, 0}
###
### Lag-order mapping to the existing globals:
###   q_L = lo_L , s_L = ld_L , q_U = lo_U , s_U = ld_U
### A single q_R governs BOTH the + and - oil terms, as in the equation.
###
### Requires d, o, dd, do_, lagv() and the four lag globals, exactly as
### the current fit_tvecm does. Drop-in: signature is still function(b).
### =====================================================================

fit_oil_asym <- function(b) {
  a  <- mean(d) - b * mean(o)          # conditional intercept
  uu <- d - a - b * o                  # cointegrating residual u_t (levels)
  
  Lmax <- max(lo_L, ld_L, lo_U, ld_U)
  
  # Exact sign decomposition of Δo:  Δo⁺ + Δo⁻ = Δo  identically.
  # Δo⁻ is NEGATIVE-valued (min, not |min|) -- see the note on interpretation.
  do_p <- pmax(do_, 0)                 # Δo⁺
  do_n <- pmin(do_, 0)                 # Δo⁻
  
  Xop <- sapply(seq_len(Lmax), function(k) lagv(do_p, k))  # Δo⁺_{t-1..Lmax}
  Xon <- sapply(seq_len(Lmax), function(k) lagv(do_n, k))  # Δo⁻_{t-1..Lmax}
  Xd  <- sapply(seq_len(Lmax), function(k) lagv(dd,   k))  # Δd_{t-1..Lmax}
  colnames(Xop) <- paste0("dop_l", seq_len(Lmax))
  colnames(Xon) <- paste0("don_l", seq_len(Lmax))
  colnames(Xd)  <- paste0("dd_l",  seq_len(Lmax))
  
  df <- data.frame(y = dd, ecm = lagv(uu, 1), Xop, Xon, Xd)
  df <- df[complete.cases(df), ]       # common window: drops first 1 + Lmax rows
  
  low <- df$ecm <= 0                   # regime split at û_{t-1} = 0
  
  # Regime-specific RHS (no constant). The `if (q > 0)` guards matter:
  # paste0("dop_l", seq_len(0)) returns "dop_l", not character(0).
  mk_form <- function(q, s)
    as.formula(paste("y ~ 0 +", paste(c(
      if (q > 0) paste0("dop_l", seq_len(q)),
      if (q > 0) paste0("don_l", seq_len(q)),
      if (s > 0) paste0("dd_l",  seq_len(s)),
      "ecm"), collapse = " + ")))
  
  form_L <- mk_form(lo_L, ld_L)
  form_U <- mk_form(lo_U, ld_U)
  
  mL <- lm(form_L, data = df[low,  ])  # lower regime  (û_{t-1} <= 0)
  mU <- lm(form_U, data = df[!low, ])  # upper regime  (û_{t-1} >  0)
  
  # Guard: a split column can be degenerate (all zeros) in a small subsample,
  # which makes lm drop it and return NA coefficients.
  if (anyNA(coef(mL)) || anyNA(coef(mU)))
    warning("NA coefficients: a Δo+/Δo- column is degenerate or collinear in a regime.")
  
  ssr <- sum(resid(mL)^2) + sum(resid(mU)^2)
  list(b = b, a = a, ssr = ssr, mL = mL, mU = mU,
       nL = sum(low), nU = sum(!low), n = nrow(df),
       lo_L = lo_L, sld_L = ld_L, lo_U = lo_U, ld_U = ld_U,
       df = df, low = low)               
}

## ---- Grid search over beta ----------------------------------------
ssrs_oil_asym <- vapply(grid, function(b) fit_oil_asym(b)$ssr, numeric(1))

b_hat_oil_asym <- grid[which.min(ssrs_oil_asym)]
best_oil_asym  <- fit_oil_asym(b_hat_oil_asym)             # final fit at the SSR-minimising beta


# F test lower coefficients
model.4.lower <- best$mL
model.4.upper <- best$mU
model.5.lower <- best_oil_asym$mL
model.5.upper <- best_oil_asym$mU

SSR_R <- sum(summary(model.4.lower)$residuals^2)
SSR_U <- sum(summary(model.5.lower)$residuals^2)
n <- nobs(model.4.lower)
k <- length(coef(model.5.lower))
m <- lo_L
  
F.lower <- ((SSR_R-SSR_U)/m)/
  (SSR_U/(n-k))

v1.lower <- m
v2.lower <- n-k 

# F test upper coefficients
SSR_R <- sum(summary(model.4.upper)$residuals^2)
SSR_U <- sum(summary(model.5.upper)$residuals^2)
n <- nobs(model.4.upper)
k <- length(coef(model.5.upper))
m <- lo_U

F.upper <- ((SSR_R-SSR_U)/m)/
  (SSR_U/(n-k))

v1.upper <- m
v2.upper <- n-k 

# Print results
F.lower
v1.lower
v2.lower

F.upper
v1.upper
v2.upper

setwd('/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT')
save.image(file='F_test_DL draft 1.RData')