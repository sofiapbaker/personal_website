# This R script is to select lag lengths for the models in rural/urban/national series given 
# a single threshold at zero. 

# - Check the lag length for each individual equation (i.e., allow for different lag lengths
# between oil and diesel price equations). In these tests, also test for if lag of oil price 
# change should be zero.

# - I will run each oil price equation and diesel price equation on their own using OLS and
# choose lag lengths based on BIC for each individual equation

# - I will also allow the lags of oil price changes and diesel price changes to be different
# within the diesel price equation

# Run the BIC using the same N in each lag specification

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT d_t is on LHS of cointegrating regression
## ORIGINAL FILE: Daily TVECM - restricted lag selection draft 5.R

# I am choosing lags using BIC on two-stage estimated TVECM

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(systemfit)
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

#---------------------- Prepare Data --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), ~log(.), .names = "log_{col}"))
diesel <- dplyr::select(diesel, -oil,-national,-rural,-urban)

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))


# Run regressions of different diesel series on oil to get ect estimates.
data <- diesel; rm(diesel)

LR_national <- lm(log_national~log_oil, data=data) 
LR_urban <- lm(log_urban~log_oil, data=data)
LR_rural <- lm(log_rural~log_oil, data=data)

summary(LR_national)
summary(LR_urban)
summary(LR_rural)

# get residuals (error correction term)
data$ect_national <- summary(LR_national)$residuals
data$ect_urban <- summary(LR_urban)$residuals
data$ect_rural <- summary(LR_rural)$residuals

# get lagged ect and differences
data <- data %>% mutate(across(starts_with("ect_"), lag,.names = "l1.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), lag,.names = "l1.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=2),.names = "l2.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=3),.names = "l3.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=4),.names = "l4.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=5),.names = "l5.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=6),.names = "l6.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=7),.names = "l7.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=8),.names = "l8.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=9),.names = "l9.{col}"))
data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=10),.names = "l10.{col}"))
# rename variables
colnames(data) <- gsub("diff_log_","D.",colnames(data))

# Drop the first row, where the lagged ect and the differenced oil/diesel series are NA. This is because
# none of the lag specifications can use this observation
data <- data[-1,]

######################################### national  #################################################

#---------------------- Split data by lagged ect --------------------------------------
data_lower <- filter(data, l1.ect_national<=0)
data_upper <- filter(data, l1.ect_national>0)

summary(data_lower)
summary(data_upper)

#---------------------- Oil eqn --------------------------------------

# write my own BIC function, which uses the same n for each lag specification
BIC_fcn <- function(estimated_model,lo,ld,n){
  BIC <- -2*logLik(estimated_model) + (lo+ld)*log(n)
  return(BIC)
}

select_lags_oil_eqn <- function(data, max_lag){
  reg.list <- list()
  BIC_table <- cbind(0:max_lag,NA); colnames(BIC_table) <- c("p","value")
  
  reg.list[[1]] <- lm(D.oil ~ - 1, data=data)
  BIC_table[1,"value"] <- BIC_fcn(reg.list[[1]],0,0,nrow(data))
  
  for(i in 1:max_lag){
    reg.list[[i+1]] <- lm(as.formula(paste('D.oil~ -1 + ',paste0('l',1:i,'.D.oil', collapse=" + "))), data=data)
    BIC_table[i+1,"value"] <- BIC_fcn(reg.list[[i+1]],i,0,nrow(data))
  }
  
  selected_p <- BIC_table[which.min(BIC_table[,"value"]),]
  return(selected_p)
}

select_lags_oil_eqn(data_lower,10) # 0
select_lags_oil_eqn(data_upper,10) # 0

#---------------------- Diesel eqn --------------------------------------
diesel_eqn_regression <- function(lo,ld,data){
  if(lo>0){
    lm(as.formula(paste('D.diesel~ -1 + l1.ect_diesel +',
                        paste0('l',1:lo,'.D.oil', collapse=" + ")," + ",
                        paste0('l',1:ld,'.D.diesel', collapse=" + ")
    )), data=data)
  } else{
    lm(as.formula(paste('D.diesel~ -1 + l1.ect_diesel +',
                        paste0('l',1:ld,'.D.diesel', collapse=" + ")
    )), data=data)
  }
  
}

# make sure to type group in quotations ("national","rural" or "urban")
select_lags_diesel_eqn <- function(data, group, max_lo, max_ld){ 
  
  colnames(data) <- gsub(group,"diesel", colnames(data))
  
  BIC_table <- cbind(lo=rep(0:max_lo,max_ld),ld=rep(1:max_ld,each=(max_lo+1)),value=NA)
  
  BIC_table[,"value"] <- apply(BIC_table,1,function(x) 
    BIC_fcn(diesel_eqn_regression(lo=x["lo"],ld=x["ld"],data),
            lo=x["lo"],ld=x["ld"],n=nrow(data)))
  
  selected_p <- BIC_table[which.min(BIC_table[,"value"]),]
  return(selected_p)
}

select_lags_diesel_eqn(data_lower,"national",10,10) # (lo,ld)=(5,5)
select_lags_diesel_eqn(data_upper,"national",10,10) # (lo,ld)=(6,6) 

######################################### rural  #################################################

#---------------------- Split data by lagged ect --------------------------------------
data_lower <- filter(data, l1.ect_rural<=0)
data_upper <- filter(data, l1.ect_rural>0)

summary(data_lower)
summary(data_upper)

# Oil eqn
select_lags_oil_eqn(data_lower,10) # 0
select_lags_oil_eqn(data_upper,10) # 0

# Diesel eqn
select_lags_diesel_eqn(data_lower,"rural",10,10) # (lo,ld)=(8,1)
select_lags_diesel_eqn(data_upper,"rural",10,10) # (lo,ld)=(6,5)

######################################### urban  #################################################

#---------------------- Split data by lagged ect --------------------------------------
data_lower <- filter(data, l1.ect_urban<=0)
data_upper <- filter(data, l1.ect_urban>0)

summary(data_lower)
summary(data_upper)

# Oil eqn
select_lags_oil_eqn(data_lower,10) # 0
select_lags_oil_eqn(data_upper,10) # 0

# Diesel eqn
select_lags_diesel_eqn(data_lower,"urban",10,10) # (lo,ld)=(5,4)
select_lags_diesel_eqn(data_upper,"urban",10,10) # (lo,ld)=(6,5)

######################################### symmetric, national  #################################################
# Oil eqn
select_lags_oil_eqn(data,10) # 0

# Diesel eqn
select_lags_diesel_eqn(data,"national",10,10) # (lo,ld)=(6,6)

