### This R script is pooling all the diesel price change observations and plotting the
### distribution with a histogram

### This is the code for "plot using histogram draft 3" but run on newly cleaned data

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
require(dplyr)

# 1) import data -------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Data cleaning 2024-09")
load("cleaned_pre_tax_price_changes.RData")

data <- cleaned_pre_tax_price_changes
rm(cleaned_pre_tax_price_changes)

# 2) put the data into a single vector ------------------
data$Date <- NULL; colnames(data) <- NULL
data <- as.matrix(data)
vector <- matrix(data=data, ncol=1)
#setequal(vector, data) # check that vector and original matrix have the same information - comment out because it's slow
vector <- vector[!is.na(vector)] # remove NA values
sum(is.na(vector))==0 # check for remaining NAs

# 3) Prepare data for histogram -------------
vector_full <- vector # save complete vector
vector <- vector[vector != 0] # remove zeros

# turn vector into a dataframe to use it with ggplot2
plot_data <- as.data.frame(vector); colnames(plot_data) <- "percent_change_in_price"

# multiply the percentage change by 100
plot_data$percent_change_in_price <- plot_data$percent_change_in_price*100

# ----------------------make histogram
# bin width is 0.2 in Gautier and Le Saout Figure 2, and rannge is +- 10%
library(ggplot2)
library(moments)

# make the base for ggplot
base <-  plot_data %>% ggplot(aes(x=percent_change_in_price))

# basic histogram:
base + geom_histogram(binwidth = 0.2, fill="blue")

base + geom_histogram(binwidth = 0.2, fill="blue") +
  annotate("text", x = Inf, y = Inf, hjust = 1.1, vjust = 1.1,
           label = paste("Mean:", round(mean(plot_data$percent_change_in_price), 2), 
                         "\nVariance:", round(var(plot_data$percent_change_in_price), 2), 
                         "\nSkewness:", round(skewness(plot_data$percent_change_in_price), 2), 
                         "\nKurtosis:", round(kurtosis(plot_data$percent_change_in_price), 2)
           ))

### zooming in to different sections:

# +- 10 
base + geom_histogram(binwidth = 0.2, fill="blue") +
  coord_cartesian(xlim=c(-10,10)) + scale_x_continuous(
    breaks = seq(-10, 10, 1)
  ) 

# +- 20
base + geom_histogram(binwidth = 0.2, fill="blue") +
  coord_cartesian(xlim=c(-20,20)) + scale_x_continuous(
    breaks = seq(-20, 20, 5)
  ) 

### next, look only at edges:
# > 10 
plot_data %>% filter(percent_change_in_price > 10) %>% 
  ggplot(aes(x=percent_change_in_price)) +
  geom_histogram(binwidth = 0.2, fill="blue") 

# < -10 
plot_data %>% filter(percent_change_in_price < -10) %>% 
  ggplot(aes(x=percent_change_in_price)) +
  geom_histogram(binwidth = 0.2, fill="blue") 

### Cleaned plots for presentation
# Whole sample
base + geom_histogram(aes(y = after_stat(count / sum(count))),
                      binwidth = 0.2, fill="blue") +
  scale_y_continuous(labels = scales::percent)+
  ylab("Percent of nonzero price changes") +
  xlab("Diesel price change in %")

# +- 10 
base + geom_histogram(aes(y = after_stat(count / sum(count))),
                      binwidth = 0.2, fill="blue") +
  coord_cartesian(xlim=c(-10,10)) + scale_x_continuous(
    breaks = seq(-10, 10, 1)) +
  scale_y_continuous(labels = scales::percent) +
  ylab("Percent of nonzero price changes") +
  xlab("Diesel price change in %")


