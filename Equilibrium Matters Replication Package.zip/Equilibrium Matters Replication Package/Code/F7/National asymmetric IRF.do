/*This do file is to run asymmetric versions of the IRF given by eq(8) of Gautier et al. (2023)
- Use the base code from Figure4.do.
- See how to generate dummies for positive and negative wholesale price changes, and how to interact them with changes in wholesale prices from Table4.do.
*/

clear all
capture log close

**** Set global path and install packages - this code is taken from 00_Main.do ****

* Install necessary packages

ssc install egenmore
ssc install geonear
ssc install geodist
ssc install winsor2
ssc install binscatter // I added this - it is needed for Figure5and6.do

* Set path

global path "/Users/olgabaker/Desktop/Miller work/gas data/French data/Running Gautier 2023 Replication Package"

///////////////////////////////////////////////////////////////// Start the code from Figure4.do:


use "$path/Intermediary Data/localshock_dataforReg_v2.dta",clear

drop if prix_ht==.
drop  j j3
replace d_dieselr=resid_movav_diesel
xtset id daten
gen d_dieselrott=ln(diesel_rotterdam_euro)-ln(l1.diesel_rotterdam_euro)
drop diesel_rotterdam_euro resid_movav_diesel dprix1 

drop d_dieselr
gen d_dieselr=d_dieselrott

merge m:m id using  "$path/Intermediary Data/base_id_suff_stat_6Y"
keep if _m==3
drop _m

merge m:m id using  "$path/Intermediary Data/base_base_suff_stat_6Y_forinteractkurtfreq"
keep if _m==3
drop _m

capture drop coeff1_reg
capture drop coeff2_reg
capture drop coeff_c_reg


capture drop se_coeff1_reg
capture drop se_coeff2_reg
capture drop df_reg


gen coeff1_reg=.
gen coeff2_reg=.
gen coeff_c_reg=.


gen se_coeff1_reg=.
gen se_coeff2_reg=.
gen df_reg=.

/// Generate positive and negative wholesale price change variables. These are equivalent to positive and negative price change dummies multiplied by the cost change
gen d_dieselr_pos=.
replace d_dieselr_pos=d_dieselr if d_dieselr>=0 & d_dieselr!=.
replace d_dieselr_pos=0 if d_dieselr<0 & d_dieselr!=.

gen d_dieselr_neg=.
replace d_dieselr_neg=d_dieselr if d_dieselr<0 & d_dieselr!=.
replace d_dieselr_neg=0 if d_dieselr>=0 & d_dieselr!=.
///

capture drop num_obs
gen num_obs=_n-1

foreach i of numlist 0/15 16(2)40{
capture drop  f_prix_ht

bysort id (daten):  gen f_prix_ht=log(prix_ht[_n+`i'])-log(prix_ht[_n-1])

// Add positive and negative diesel price change terms:

/* Original
areg f_prix_ht d_dieselr local_shock10 m_dprix l.d_dieselr l2.d_dieselr l3.d_dieselr l4.d_dieselr l5.d_dieselr ///
		l.local_shock10  l2.local_shock10 l3.local_shock10 l4.local_shock10 l5.local_shock10 ///
	l.m_dprix  l2.m_dprix l3.m_dprix l4.m_dprix l5.m_dprix  , absorb(id) vce(cluster daten)
*/
	
areg f_prix_ht d_dieselr_pos d_dieselr_neg local_shock10 m_dprix ///
l.d_dieselr_pos l2.d_dieselr_pos l3.d_dieselr_pos l4.d_dieselr_pos l5.d_dieselr_pos ///
l.d_dieselr_neg  l2.d_dieselr_neg  l3.d_dieselr_neg l4.d_dieselr_neg  l5.d_dieselr_neg ///
l.local_shock10  l2.local_shock10 l3.local_shock10 l4.local_shock10 l5.local_shock10 ///
l.m_dprix  l2.m_dprix l3.m_dprix l4.m_dprix l5.m_dprix  , absorb(id) vce(cluster daten)
	
// I changed coeff1 to refer to theta_plus and coeff2 to refer to theta_minus	
matrix test=r(table)
replace coeff1_reg=_b[d_dieselr_pos] if num_obs==`i'
replace coeff2_reg=_b[d_dieselr_neg] if num_obs==`i'
replace coeff_c_reg=_b[_cons] if num_obs==`i'



replace se_coeff1_reg=_se[d_dieselr_pos] if num_obs==`i'
replace se_coeff2_reg=_se[d_dieselr_neg] if num_obs==`i'
replace df_reg=e(df_r) if num_obs==`i'
capture drop  f_prix_ht

}


keep coeff1_reg coeff2_reg coeff_c_reg  se_coeff1_reg se_coeff2_reg df_reg num_obs
keep if num_obs<=40
gen name="BASELINE 1"
gen charact="LAGS, STANDARD SHOCK, STATION FE, DATE CLUSTER"
save "$path/Graphs_Tables/Data_National_asymmetric_IRF.dta", replace




use "$path/Graphs_Tables/Data_National_asymmetric_IRF.dta", clear

gen ci_coeff1_m=coeff1_reg-1.96*se_coeff1_reg
gen ci_coeff1_p=coeff1_reg+1.96*se_coeff1_reg


local nj=40
sort num_obs
graph twoway (rarea  ci_coeff1_m ci_coeff1_p num_obs if num_obs<=`nj', col(grey%10)) ///
(line  coeff1_reg num_obs if num_obs<=`nj', col(black) ///
legend(off) graphregion(color(white)) xtitle("Time (in days)") ytitle("Cum. Response")) ///
, xlabel(0(2)`nj') ylabel(0(0.1)1) 
graph export "$path/Graphs_Tables/National_asymmetric_IRF.png", replace
graph export "$path/Graphs_Tables/National_asymmetric_IRF.eps", replace

