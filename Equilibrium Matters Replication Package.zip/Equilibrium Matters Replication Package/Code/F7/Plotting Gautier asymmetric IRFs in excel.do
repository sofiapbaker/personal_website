/* This do file is to get the results to generate graphs for asymmetric IRFs using Gautier's model in excel. These results were generated in "National asymmetric IRF.do"
*/

clear all 
capture log close 
set more off

global path "/Users/olgabaker/Desktop/Miller work/gas data/French data/Running Gautier 2023 Replication Package/Graphs_Tables"

use "$path/Data_National_asymmetric_IRF.dta", clear

* export
cd "/Users/olgabaker/Desktop/Miller work/TVECM/IRF/Daily/Output/asymmetric"

export delimited using "Gautier_model_National_asymmetric_IRF_data.csv", replace 
