### This R script is to calculate the cumulative adjustment function for the symmetric BG model
# Do national group only
# Use (lo,ld) = 6
# Draft 2: correcting the formula for the negative IRF

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

#---------------------- Prepare Data --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), ~log(.), .names = "log_{col}"))
diesel <- dplyr::select(diesel, -oil,-national,-rural,-urban)

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))

# Run regressions of diesel on oil to get ect estimates
data <- diesel; rm(diesel)

LR_national <- lm(log_national~log_oil, data=data) 
LR_urban <- lm(log_urban~log_oil, data=data)
LR_rural <- lm(log_rural~log_oil, data=data)

summary(LR_national)
summary(LR_urban)
summary(LR_rural)

# get residuals (error correction term)
data$z_national <- summary(LR_national)$residuals
data$z_urban <- summary(LR_urban)$residuals
data$z_rural <- summary(LR_rural)$residuals

# get lagged z 
data <- data %>% mutate(across(starts_with("z_"), lag,.names = "l1.{col}"))

# get lagged differences
max_lag <- 6
for(i in 1:max_lag){
  name <- paste0("l",i,".{col}")
  data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=i),.names = name))
}
colnames(data) <- gsub("diff_log_","D.",colnames(data))

# get dummies for positive and negative differences
data <- data %>% mutate(across(ends_with("D.oil"), ~ifelse(.>0,1,0),.names = "positive_{col}"))
data <- data %>% mutate(across(ends_with("D.oil") & !starts_with("positive"), 
                               ~ifelse(.<=0,1,0),.names = "negative_{col}"))

# Drop the first two rows, where the first lagged difference of diesel price is NA. This is because
# none of the lag specifications can use these observations
data <- data[-1:-2,]

#---------------------- Run model --------------------------------------
# code model with lo,ld=1
reg1 <- lm(D.national~ -1 + positive_D.oil:l1.z_national + negative_D.oil:l1.z_national + l1.D.national + 
             positive_D.oil:D.oil + positive_l1.D.oil:l1.D.oil +
             negative_D.oil:D.oil + negative_l1.D.oil:l1.D.oil , data=data)

summary(reg1)

# write function for longer lags
asymmetric_BG_regression <- function(lo,ld,data,group){
  
  colnames(data) <- gsub(group,"diesel", colnames(data))
  
  if(lo>0){
    lm(as.formula(paste('D.diesel~ -1 + positive_D.oil:l1.z_diesel + negative_D.oil:l1.z_diesel + ', 
                        paste0('l',1:ld,'.D.diesel', collapse=" + "),
                        "+ positive_D.oil:D.oil +", 
                        paste0('positive_l',1:lo,'.D.oil:','l',1:lo,'.D.oil', collapse=" + "),
                        "+ negative_D.oil:D.oil +", 
                        paste0('negative_l',1:lo,'.D.oil:','l',1:lo,'.D.oil', collapse=" + ")
    )), data=data)
  } else{
    lm(as.formula(paste('D.diesel~ -1 + positive_D.oil:l1.z_diesel + negative_D.oil:l1.z_diesel + ', 
                        paste0('l',1:ld,'.D.diesel', collapse=" + "),
                        "+ positive_D.oil:D.oil + negative_D.oil:D.oil"
    )), data=data)
  }
}

# check work
reg2 <- asymmetric_BG_regression(1,1,data,"national")
coef(reg1)==coef(reg2)

# get estimates
lo <- 6; ld <- 6
national_model_asymmetric <- asymmetric_BG_regression(lo,ld,data,"national") 
summary(national_model_asymmetric)

# Write cumulative adjustment functions -----------------------------------------------------
length_out <- 40

gamma0 <- coef(LR_national)["(Intercept)"]
gamma1 <- coef(LR_national)["log_oil"]

coefs <- coef(national_model_asymmetric)

theta_plus <- coefs["positive_D.oil:l1.z_diesel"]
theta_minus <- coefs["l1.z_diesel:negative_D.oil"]

beta_d <-coefs[endsWith(names(coefs),"D.diesel")]

coefs <- coefs[!(names(coefs) %in% c(names(theta_plus),names(theta_minus),names(beta_d)))]

names(beta_d) <- gsub(".D.diesel","", names(beta_d))
beta_d_filler <- rep(0,length_out)
names(beta_d_filler) <- paste0("l",(ld+1):(ld+length_out))
beta_d <- c(beta_d, beta_d_filler)

for(i in lo:1){
  string_to_remove <- paste0("l",i,".D.oil:")
  names(coefs) <- gsub(string_to_remove,"", names(coefs))
}

names(coefs) <- gsub("D.oil:","", names(coefs))

beta_o_plus <- coefs[startsWith(names(coefs),"positive")]
names(beta_o_plus) <- gsub("positive_","", names(beta_o_plus))
names(beta_o_plus)[names(beta_o_plus)=="D.oil"] <- "l0.D.oil"
names(beta_o_plus) <- gsub(".D.oil","", names(beta_o_plus))
beta_o_plus_filler <- rep(0,length_out)
names(beta_o_plus_filler) <- paste0("l",(lo+1):(lo+length_out))
beta_o_plus <- c(beta_o_plus, beta_o_plus_filler)

beta_o_minus <- coefs[startsWith(names(coefs),"negative")]
names(beta_o_minus) <- gsub("negative_","", names(beta_o_minus))
names(beta_o_minus)[names(beta_o_minus)=="D.oil"] <- "l0.D.oil"
names(beta_o_minus) <- gsub(".D.oil","", names(beta_o_minus))
beta_o_minus_filler <- rep(0,length_out)
names(beta_o_minus_filler) <- paste0("l",(lo+1):(lo+length_out))
beta_o_minus <- c(beta_o_minus, beta_o_minus_filler)

###### Positive Adjustment Function
B_plus <- rep(NA,length_out+2)
names(B_plus) <- paste0("t",-1:40)

B_plus["t-1"] <- 0
B_plus["t0"] <- beta_o_plus["l0"]
B_plus["t1"] <- B_plus["t0"] + beta_o_plus["l1"] + theta_minus*(B_plus["t0"]-gamma1) + beta_d["l1"]*B_plus["t0"]
B_plus["t2"] <- B_plus["t1"] + beta_o_plus["l2"] + theta_minus*(B_plus["t1"]-gamma1) + beta_d["l1"]*(B_plus["t1"]-B_plus["t0"]) + beta_d["l2"]*B_plus["t0"]

for(k in 3:40){
  summation <- rep(NA,k)
  for(i in 1:k){
    summation[i] <- beta_d[paste0("l",i)]*(B_plus[paste0("t",k-i)]-B_plus[paste0("t",k-i-1)])
  }
  
  B_plus[paste0("t",k)] <- B_plus[paste0("t",k-1)] + beta_o_plus[paste0("l",k)] + theta_minus*(B_plus[paste0("t",k-1)]-gamma1) +
    sum(summation)
}

B_plus <- B_plus[-1]
B_plus

###### Negative Adjustment Function
B_minus <- rep(NA,length_out+2)
names(B_minus) <- paste0("t",-1:40)

B_minus["t-1"] <- 0
B_minus["t0"] <- -beta_o_minus["l0"]
B_minus["t1"] <- B_minus["t0"] - beta_o_minus["l1"] + theta_minus*(B_minus["t0"]+gamma1) + beta_d["l1"]*B_minus["t0"]
B_minus["t2"] <- B_minus["t1"] - beta_o_minus["l2"] + theta_minus*(B_minus["t1"]+gamma1) + beta_d["l1"]*(B_minus["t1"]-B_minus["t0"]) + beta_d["l2"]*B_minus["t0"]

for(k in 3:40){
  summation <- rep(NA,k)
  for(i in 1:k){
    summation[i] <- beta_d[paste0("l",i)]*(B_minus[paste0("t",k-i)]-B_minus[paste0("t",k-i-1)])
  }
  
  B_minus[paste0("t",k)] <- B_minus[paste0("t",k-1)] - beta_o_minus[paste0("l",k)] + theta_minus*(B_minus[paste0("t",k-1)]+gamma1) +
    sum(summation)
}

B_minus <- B_minus[-1]
B_minus

# invert it for the graph
B_minus <- B_minus*-1

# export data for graph
setwd('/Users/olgabaker/Desktop/Miller work/Bachmeier Griffin model/Output')
graph_data <- cbind(0:length_out,B_minus,B_plus)
colnames(graph_data) <- c('n_days_after_shock','IRF_Negative','IRF_Positive')

write.csv(graph_data, 'BG_asymmetric_IRF_national.csv', row.names=F) 
