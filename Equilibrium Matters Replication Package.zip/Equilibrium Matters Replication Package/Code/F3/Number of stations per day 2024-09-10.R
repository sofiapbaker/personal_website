### This R script is to count the number of stations present in the data each day

### This is the code for "Number of stations per day" but run on newly cleaned data

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
require(dplyr)

# import data -------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Data cleaning 2024-09")
load("cleaned_pre_tax_price_changes.RData")

data <- cleaned_pre_tax_price_changes
rm(cleaned_pre_tax_price_changes)

# 1) are there any NAs in the Date column?
sum(is.na(data$Date))==0

# 2) for each row, calculate the number of stations

# a) first get a column of how many NAs are in each row
data_backup <- data

count_na <- function(x) sum(is.na(x)) 
data2 <- data %>% mutate(n_na = apply(.,1,count_na))

data2$n_na[1:10]

# check work
sum(is.na(data[1,]))==data2$n_na[1]
sum(is.na(data[1000,]))==data2$n_na[1000]
count_na(data2$n_na)==0 

# b) next, make a column of number of stations per day
# get this with (total number of stations - number missing)

# total number of stations in panel: 
# this is ncol(data) - 1 because the "Date" column shouldn't be counted
totl_stations <- ncol(data) - 1  
totl_stations

data2 <- data2 %>% mutate(n_stations = totl_stations - n_na)

# check work
test <- cbind(data2$n_stations[1:5],data2$n_na[1:5])
rowSums(test)==totl_stations

# c) remove extra data objects/variables
data <- data2
rm(data2)
rm(data_backup)
rm(test)
data$n_na <- NULL

# 3) Export data for plot
data <- arrange(data, Date)
plot_data <- select(data, Date, n_stations)

setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Number of Stations")
write.csv(plot_data, "n_stations_cleaned_data.csv")
