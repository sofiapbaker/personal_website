#### This R script is to replicate row 1 of Table 1 from Gautier and Le Saout (2015) using my 
#### diesel price change data from 2007-2018. 

# In this draft, I am replicating only row 1 of the table.

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
require(dplyr)

# import data -------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Data cleaning 2024-09")
load("cleaned_pre_tax_price_changes.RData")

data <- select(cleaned_pre_tax_price_changes, -Date)

#------------ Number of stations observed 
No_obs <- ncol(data)

#------------ Frequency
# a) compute frequency for each retailer. The frequency is the percent of the sample days
# where that station changed prices.
# b) compute the average of the frequencies.

#### All price changes

# freq <- (# days with non-NA value - # days with zero value)/ # days with non-NA value

freq <- function(x){
  n_non_NA <- sum(!is.na(x))
  n_zero <- length(which(x==0))
  
  output <- (n_non_NA-n_zero)/n_non_NA
  return(output)
}

freq_for_each_station <- 
  apply(data,2,freq)
summary(freq_for_each_station)

# How many stations have 1 or 0 frequency?
sum(freq_for_each_station==1) 
sum(freq_for_each_station==0) # 119 - these are a problem

# average frequency
avg_freq <- mean(freq_for_each_station)

#### Freq of price increases
freq_of_increases <- function(x){
  n_non_NA <- sum(!is.na(x))
  n_zero <- length(which(x==0))
  n_negative <- length(which(x<0))
  
  output <- (n_non_NA-n_zero-n_negative)/n_non_NA
  return(output)
}

freq_of_increases_for_each_station <- 
  apply(data,2,freq_of_increases)
summary(freq_of_increases_for_each_station)

avg_freq_of_increases <- mean(freq_of_increases_for_each_station)

#### Freq of price decreases
freq_of_decreases <- function(x){
  n_non_NA <- sum(!is.na(x))
  n_zero <- length(which(x==0))
  n_positive <- length(which(x>0))
  
  output <- (n_non_NA-n_zero-n_positive)/n_non_NA
  return(output)
}

freq_of_decreases_for_each_station <- 
  apply(data,2,freq_of_decreases)
summary(freq_of_decreases_for_each_station)

avg_freq_of_decreases <- mean(freq_of_decreases_for_each_station)



# print output for table
round(avg_freq*100,2)
round(avg_freq_of_increases*100,2)
round(avg_freq_of_decreases*100,2)
round(1/avg_freq,2) 
