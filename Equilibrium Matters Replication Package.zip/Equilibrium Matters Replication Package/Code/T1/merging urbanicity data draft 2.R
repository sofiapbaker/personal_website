# This R script is to merge the urban/rural variable in "UU2010_au_01-01-2020.dta"
# from the Gautier et al (2023) replication package with "cleaned_data_all_vars.RData".
# I will then count the number of urban and rural stations and separate 
# "cleaned_pre_tax_price_changes.RData" by urban and rural stations

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(stringr)
library(tidyverse)

#----------------------  Load urbanicity data -----------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Running Gautier 2023 Replication Package/Export data to R")
urbanicity_data <- read.csv("urbanicity_data.csv")
crossover <- read.csv("crossover_station_id_insee_code.csv")

# Check against stata file
sum(is.na(urbanicity_data$type_com))
sum(is.na(urbanicity_data$codeinsee))
sum(is.na(crossover$id_pdv))
sum(is.na(crossover$codeinsee))

# keep relevant variables
crossover <- select(crossover, id_pdv, codeinsee)
urbanicity_data <- select(urbanicity_data, codeinsee, type_com)
n_distinct(crossover$id_pdv)==nrow(crossover)

# check what percent of the stations have insee codes that appear in urbanicity data
sum(crossover$codeinsee %in% urbanicity_data$codeinsee)/nrow(crossover) # 95%

urbanicity_data <- left_join(crossover, urbanicity_data)
sum(is.na(urbanicity_data$type_com)) # 636 missing rural/urban variable
sum(!is.na(urbanicity_data$type_com))/nrow(crossover) # 95% of the stations have rural/urban variable

# replace with 0/1 variable
urbanicity_data$urban_dummy <- ifelse(urbanicity_data$type_com=="URBAIN", 1,0)

# prepare data for merge with price info
urbanicity_data$type_com <- NULL
urbanicity_data$codeinsee <- NULL
urbanicity_data <- urbanicity_data %>% rename(id_pdv_30=id_pdv)
urbanicity_data$id_pdv_30 <- as.character(urbanicity_data$id_pdv_30)

#----------------------  Load cleaned data with all price, id, and date variables included -----------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/Data cleaning 2024-09")
load("cleaned_data_all_vars.RData") 

# check how many stations in my sample have an insee code
stations_in_sample <- unique(raw_data$id_pdv_30)
sum(!(stations_in_sample %in% urbanicity_data$id_pdv_30)) # 580 stations in my sample have no id information
stations_in_sample[which(!(stations_in_sample %in% urbanicity_data$id_pdv_30))]

# Merge
raw_data <- left_join(raw_data, urbanicity_data)
summary(raw_data)

#------------ Count urban and rural stations -------------
urban_stations <- filter(raw_data, urban_dummy==1)
rural_stations <- filter(raw_data, urban_dummy==0)

n_urban_stations <- n_distinct(urban_stations$id_pdv_30)
n_rural_stations <- n_distinct(rural_stations$id_pdv_30)
n_distinct(raw_data$id_pdv_30)-n_urban_stations-n_rural_stations # 1001 stations missing urban/rural dummy
1001/n_distinct(raw_data$id_pdv_30) # 9.2% of stations are missing the dummy

#------------ separate price change data by group -------------
urban_ids <- unique(urban_stations$id_pdv_30)
rural_ids <- unique(rural_stations$id_pdv_30)

load("cleaned_pre_tax_price_changes.RData")
price_change_data <- cleaned_pre_tax_price_changes

urban_pre_tax_price_changes <- select(price_change_data, Date, all_of(urban_ids))
rural_pre_tax_price_changes <- select(price_change_data, Date, all_of(rural_ids))

save(urban_pre_tax_price_changes, file = "urban_pre_tax_price_changes.RData")
save(rural_pre_tax_price_changes, file = "rural_pre_tax_price_changes.RData")
