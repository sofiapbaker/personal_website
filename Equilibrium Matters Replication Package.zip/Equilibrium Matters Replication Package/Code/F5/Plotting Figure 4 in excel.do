/* This do file is to get the data to generate Figure 4 in excel. Note that this is different from Gautier's Figure 4 because I'm using an oil price shock instead of a wholesale price shock.
*/

clear all 
capture log close 
set more off

global path "/Users/olgabaker/Desktop/Miller work/gas data/French data/Running Gautier 2023 Replication Package/Graphs_Tables"

use "$path/Data_Figure4.dta", clear

* export
cd "/Users/olgabaker/Desktop/Miller work/TVECM/IRF/Output"

export delimited using "Gautier_replicated_Figure_4_data.csv", replace 
