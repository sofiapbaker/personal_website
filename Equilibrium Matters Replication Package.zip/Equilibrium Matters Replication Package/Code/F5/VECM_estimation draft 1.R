### This R script calculates the VECM with diesel on the LHS of the LR reg and
### six lags on oil/diesel in both regimes, using a one-step estimation procedure:
### - Grid search around the initial beta (cointegrating slope) from OLS.
### - Estimate the remaining parameters for each beta.
### - Compute the total SSR for every iteration.
### - Select the beta / parameter set that minimises the total SSR.

# MODIFYING THE BELOW CODE SO THAT there is no threshold
# /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/TVECM_estimation draft 2.R
#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

# define group and lags
group <- "national"

diesel <- select(diesel,Date,all_of(group),oil)

diesel <- diesel %>% mutate(across(-Date, ~log(.), .names = "log_{col}"))
diesel <- dplyr::select(diesel, -oil,-all_of(group))

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))
data <- diesel; rm(diesel)
colnames(data) <- gsub(group,"diesel", colnames(data))

### =====================================================================
### VECM estimation
###
### Long run (cointegrating regression):
###     d_t = a + b o_t + u_t
###
### Short run (error-correction, single equation for Δd_t):
###     Δd_t = Σ_{i=1}^{6} π_i^o Δo_{t-i}
###          + Σ_{i=1}^{6} π_i^d Δd_{t-i}
###          + δ û_{t-1} + ε_Rt
###
### d_t = log_diesel, o_t = log_oil. 
### =====================================================================

## ---- 0. Estimation settings ------------------------------------------
n_lags     <- 6      # lags on Δo and Δd in each regime
grid_n     <- 401    # number of candidate beta values in the grid
grid_half  <- 0.10   # half-width of the beta grid: search over b0 ± grid_half
                     #   -> if the selected beta lands on a grid boundary
                     #      (flagged below), widen grid_half and re-run.

# The short-run equation has no constant, exactly as written: each regime is
# fit as a regression through the origin.

## ---- 1. Series and a simple row-shift lag ----------------------------
d   <- data$log_diesel          # d_t
o   <- data$log_oil             # o_t
dd  <- data$diff_log_diesel     # Δd_t  (row 1 is NA from differencing)
do_ <- data$diff_log_oil        # Δo_t  (row 1 is NA from differencing)

# Row-shift lag (treats consecutive rows as consecutive trading days, which is
# the standard convention for daily price series with weekend/holiday gaps).
lagv <- function(x, k) c(rep(NA, k), head(x, -k))

## ---- 2. Initial cointegrating regression (OLS) -----------------------
lr0   <- lm(d ~ o)                                        # d_t = a + b o_t + u_t
b0    <- unname(coef(lr0)["o"])
a0    <- unname(coef(lr0)["(Intercept)"])
se_b0 <- summary(lr0)$coefficients["o", "Std. Error"]

## ---- 3. Fit the vecm for a single candidate beta --------------------
## For each beta the intercept is re-set to the conditional-OLS value
##     a(b) = mean(d) - b*mean(o)
## so the residual u_t = d_t - a(b) - b o_t always has mean zero and the
## threshold at 0 keeps its interpretation (diesel above vs. below the
## long-run relation). To instead hold the intercept at the initial OLS
## value, replace the a line with:  a <- a0
rhs  <- c(paste0("do_l", 1:n_lags), paste0("dd_l", 1:n_lags), "ecm")
form <- as.formula(paste("y ~ 0 +", paste(rhs, collapse = " + ")))  # no constant

fit_vecm <- function(b) {
  a  <- mean(d) - b * mean(o)          # conditional intercept
  uu <- d - a - b * o                  # cointegrating residual u_t (levels)

  Xdo <- sapply(1:n_lags, function(k) lagv(do_, k))   # Δo_{t-1..6}
  Xdd <- sapply(1:n_lags, function(k) lagv(dd,  k))   # Δd_{t-1..6}
  df  <- data.frame(y = dd, ecm = lagv(uu, 1), Xdo, Xdd)
  colnames(df) <- c("y", "ecm", paste0("do_l", 1:n_lags), paste0("dd_l", 1:n_lags))
  df  <- df[complete.cases(df), ]      # drops the first (1 + n_lags) rows

  mS  <- lm(form, data = df)   # lower regime  (û_{t-1} <= 0)

  ssr <- sum(resid(mS)^2)
  list(b = b, a = a, ssr = ssr, mS = mS, n = nrow(df))
}

## ---- 4. Grid search over beta ----------------------------------------
grid <- seq(b0 - grid_half, b0 + grid_half, length.out = grid_n)
ssrs <- vapply(grid, function(b) fit_vecm(b)$ssr, numeric(1))

b_hat <- grid[which.min(ssrs)]
best  <- fit_vecm(b_hat)             # final fit at the SSR-minimising beta

## ---- 5. Diagnostics on the search ------------------------------------
on_boundary <- (which.min(ssrs) %in% c(1L, grid_n))
if (on_boundary)
  warning("Selected beta is on a grid boundary -- widen 'grid_half' and re-run.")

## ---- 6. Report -------------------------------------------------------
cat("=====================================================================\n")
cat(" VECM ", n_lags, " lags \n", sep = "")
cat("=====================================================================\n")
cat(sprintf("Initial OLS slope  b0 = %.4f  (SE %.4f)\n", b0, se_b0))
cat(sprintf("Initial OLS intcpt a0 = %.4f\n", a0))
cat(sprintf("Grid: [%.4f, %.4f] with %d points; argmin interior = %s\n",
            min(grid), max(grid), grid_n, !on_boundary))
cat(sprintf("Selected slope     b  = %.4f\n", best$b))
cat(sprintf("Implied intercept  a  = %.4f\n", best$a))
cat(sprintf("Obs used            n = %d   \n",
            best$n))
cat(sprintf("Total SSR             = %.6f\n\n", best$ssr))

cat("---- Single regime   --------------------------------\n")
print(summary(best$mS)$coefficients)

## Tidy combined coefficient table (regime, term, estimate, se, t, p)
tidy_reg <- function(m, regime) {
  s <- summary(m)$coefficients
  data.frame(term = rownames(s),
             estimate = s[, 1], se = s[, 2], t = s[, 3], p = s[, 4],
             row.names = NULL)
}
vecm_coefs <- tidy_reg(best$mS)

## Objects kept for downstream use:
##   best$b, best$a        : selected cointegrating vector (1, -b) with intercept a
##   best$mS     : fitted regression (lm object)
##   vecm_coefs           : tidy coefficient table
##   grid, ssrs            : SSR profile over the beta grid

# save output
setwd('/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT')
save.image(file='VECM_estimation draft 1.RData')

## ---- 7. (optional) SSR profile plot ----------------------------------
# plot(grid, ssrs, type = "l", xlab = expression(beta), ylab = "total SSR",
#      main = "SSR profile over the cointegrating slope")
# abline(v = b_hat, lty = 2)
