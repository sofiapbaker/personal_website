### This R script is to make bootstrap confidence intervals for the one-stage-estimation VECM IRF with daily data

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT the IRF is symmetric
## /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/IRF_bootstrap draft 2.R

# draft 2: fixing typo where best_til was being calculated by fit.vecm instead of fit.D.dtil
#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
load("IRF_symmetric_estimation draft 1.RData")
IRF_hat <- IRF_positive

# Bootstrap reps ---------------------------------------------------------------------------------------------------------
R <- 999
IRF_matrix <- matrix(NA,length(IRF_hat),R+1)
IRF_matrix[,R+1] <- IRF_hat

epshat <- summary(best$mS)$residuals

# get lagged differences 
for(i in 1:max_lag){
  name <- paste0("l",i,".{col}")
  data <- data %>% mutate(across(starts_with("diff_"), ~lag(.,n=i),.names = name))
}
colnames(data) <- gsub("diff_log_","D.",colnames(data))

# get first lag of oil and diesel
data <- data %>% mutate(l1.o=lag(log_oil),l1.d=lag(log_diesel))

# crop sample
data <- data[complete.cases(data),]

# Bootstrap function ---------------------------------------------------------------------------------------------------------
bootstrap <- function(r){
  boot <- data 
  
  # PART B: Resample from residuals @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  set.seed(r)
  
  epstil <- sample(epshat,length(epshat),replace=T)
  
  # PART C: get D.dtil @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  j <- 1
  boot$D.dtil <- NA
  for(t in 1:nrow(boot)){
      summation_pi_o <- rep(NA, lo)
      for(i in 1:lo){
        summation_pi_o[i] <- pi_o_hat[paste0("l",i)] * boot[[paste0("l",i,".D.oil")]][t]
      }
      summation_pi_d <- rep(NA, ld)
      for(i in 1:ld){
        summation_pi_d[i] <- pi_d_hat[paste0("l",i)] * boot[[paste0("l",i,".D.diesel")]][t]
      }
      boot$D.dtil[t] <- sum(summation_pi_o) + sum(summation_pi_d) +
        delta_hat * (boot$l1.d[t]-ahat-bhat*boot$l1.o[t]) + epstil[j]
      j <- j+1
    } 
  
  
  # PART D: Get a_til,b_til,pi_til,delta_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  # Edit fit.vecm so y is D.dtil
  fit_D.dtil <- function(b) {
    a  <- mean(d) - b * mean(o)          # conditional intercept
    uu <- d - a - b * o                  # cointegrating residual u_t (levels)
    
    Xdo <- sapply(1:n_lags, function(k) lagv(do_, k))   # Δo_{t-1..6}
    Xdd <- sapply(1:n_lags, function(k) lagv(dd,  k))   # Δd_{t-1..6}
    D.dtil <- c(rep(NA,length(d)-length(boot$D.dtil)),boot$D.dtil)
    df  <- data.frame(y = D.dtil, ecm = lagv(uu, 1), Xdo, Xdd)
    colnames(df) <- c("y", "ecm", paste0("do_l", 1:n_lags), paste0("dd_l", 1:n_lags))
    df  <- df[complete.cases(df), ]      # drops the first (1 + n_lags) rows
    
    mS  <- lm(form, data = df)   

    ssr <- sum(resid(mS)^2) 
    list(b = b, a = a, ssr = ssr, mS = mS, n = nrow(df))
  }
  
  # Grid search over beta 
  ssrs_D.dtil <- vapply(grid, function(b) fit_D.dtil(b)$ssr, numeric(1))
  
  b_til <- grid[which.min(ssrs_D.dtil)]
  best_til  <- fit_D.dtil(b_til)             # final fit at the SSR-minimising beta
  
  # Code the parameters ############################################
  atil <- best_til$a
  btil <- best_til$b
  
  # Lower regime
  coefs_til <- coef(best_til$mS)
  delta_til <- coefs_til["ecm"]
  
  pi_o_til <- coefs_til[startsWith(names(coefs_til),"do_")]
  names(pi_o_til) <- gsub("do_","",names(pi_o_til))
  
  pi_d_til <- coefs_til[startsWith(names(coefs_til),"dd_")]
  names(pi_d_til) <- gsub("dd_","",names(pi_d_til))

  
  # PART E: Get IRF_til and neg_IRF_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  IRF_til <- IRF.function(0.01,atil,btil,pi_o_til,pi_d_til,delta_til)
  
  return(IRF_til)
}

# run bootstrap
start.time <- Sys.time()
for(r in 1:R){
  IRF_matrix[,r] <- bootstrap(r)
  print(r)
}
duration <- Sys.time() - start.time
#---------------------- Save bootstrap output --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
save.image(file='IRF_symmetric_bootstrap draft 2.RData')
load('IRF_symmetric_bootstrap draft 2.RData') # use to load the R objects without running the above code

# PART F: Repeat B-E a total of R=999 times and get CIs for IRF_til @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

# use the quantile() function with type=6, as Dave does in his second year textbook
quantile(IRF_matrix[2,],probs=0.025,type=6)
quantile(IRF_matrix[2,],probs=0.975,type=6)

# Positive CI
CI_lower <- apply(IRF_matrix, 1, quantile, probs=.025,type=6)
CI_upper <- apply(IRF_matrix, 1, quantile, probs=0.975,type=6)
CI_lower<=CI_upper

CI <- cbind(n_days_after_shock=0:n_out,CI_lower=CI_lower,CI_upper=CI_upper)
write.csv(CI, "IRF_symmetric_bootstrap draft 2.csv",row.names=F)
  
