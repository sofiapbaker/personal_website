### This R script is to calculate a symmetric IRF 

## THIS SCRIPT IS MODIFYING THE BELOW SO THAT the IRF is symmetric
## /Users/olgabaker/Desktop/ONE STEP ESTIMATION/CODE/IRF_estimation draft 1.R

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)

#---------------------- Load TVECM output --------------------------------------
setwd("/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT")
load("VECM_estimation draft 1.RData")

# define group and lags
group <- "national"
lo <- n_lags
ld <- n_lags

#------------------------- Define functions ---------------------------
# Set fixed values for functions
n_out <- 40
d0 <- mean(data$log_diesel)
max_lag <- max(lo,ld)

IRF.function <- function(shock,a,b,pi_o,pi_d,delta){
  diesel_series_given_oil <- function(oil_series){
    
    # initialization
    d <- rep(NA,max_lag+n_out+2)
    d[1:(max_lag+1)] <- d0
    o <- oil_series
    
    # predict diesel based on oil
    # note that diff(o) does not put an NA at start of the vector so diff(o)[t] = o[t+1]-o[t]
    for(t in (max_lag+1):(n_out+max_lag+1)){
      summation_pi_o <- rep(NA, lo)
      for(i in 1:lo){
        summation_pi_o[i] <- pi_o[paste0("l",i)]*diff(o)[t-i]
      }
      summation_pi_d <- rep(NA, ld)
      for(i in 1:ld){
        summation_pi_d[i] <- pi_d[paste0("l",i)]*diff(d)[t-i]
      }
      
      d[t+1] <- d[t-1+1] + 
        delta*(d[t-1+1]-a-b*o[t-1+1]) + sum(summation_pi_o) + sum(summation_pi_d) 
    }
    
    # finalization 
    d <- d[-1:-(max_lag+1)]
    
    return(d)
  }
  
  o0 <- (-a/b) + (1/b)*d0; names(o0) <- NULL
  oil_no_shock <- rep(o0, 1000)
  d_no_shock <- diesel_series_given_oil(oil_no_shock)
  
  oil_with_shock <- c(rep(o0,max_lag+1),rep(o0+shock, 1000-(max_lag+1)))
  d_with_shock <- diesel_series_given_oil(oil_with_shock)
  IRF <- 100*(d_with_shock - d_no_shock) 
  return(IRF)
}

# Code the parameters ############################################
ahat <- best$a
bhat <- best$b

# Lower regime
coefs <- coef(best$mS)
delta_hat <- coefs["ecm"]

pi_o_hat <- coefs[startsWith(names(coefs),"do_")]
names(pi_o_hat) <- gsub("do_","",names(pi_o_hat))

pi_d_hat <- coefs[startsWith(names(coefs),"dd_")]
names(pi_d_hat) <- gsub("dd_","",names(pi_d_hat))

IRF_positive <- IRF.function(0.01,ahat,bhat,pi_o_hat,pi_d_hat,delta_hat)

IRF_negative <- IRF.function(-0.01,ahat,bhat,pi_o_hat,pi_d_hat,delta_hat)

IRF_positive==-IRF_negative 

# 7) Export data for a graph ########################################################
graph_data <- cbind(n_days_after_shock=0:n_out,
                    IRF=IRF_positive)

setwd('/Users/olgabaker/Desktop/ONE STEP ESTIMATION/OUTPUT')
file <- paste0("IRF_",group,"_symmetric.csv")
write.csv(graph_data, file, row.names=F) 
save.image(file='IRF_symmetric_estimation draft 1.RData')
