# This R script is to run the Zivot-Andrews unit root test on the urban/rural/national series
# and the oil price. 
# - I will run the test on log price series, and first difference of log price series
# - I will test for broken trend and broken mean for prices in levels
# - I will test for broken mean for differenced series

#------------------------- close connections to log files -------------
closeAllConnections()

#------------------------- open required packages ----------------------
library(tidyverse)
library(urca)

#---------------------- Load data --------------------------------------
setwd("/Users/olgabaker/Desktop/Miller work/gas data/French data/CREATING AGGREGATED SERIES")
load("two_group_prices_daily_with_oil.RData")

#---------------------- Create log prices and their first diff --------------------------------------
diesel <- diesel %>% mutate(across(c(2:5), ~log(.), .names = "log_{col}"))

diesel <- arrange(diesel,Date)
diesel <- diesel %>% mutate(across(starts_with("log_"), ~.-lag(.),.names = "diff_{col}"))

                                          
#---------------------- Run tests --------------------------------------
data <- diesel; rm(diesel)

test_log_oil <- ur.za(data$log_oil, model="both")
summary(test_log_oil) # fail to reject unit root null

test_diff_log_oil <- ur.za(data$diff_log_oil, model="intercept")
summary(test_diff_log_oil) # reject unit root null

test_log_national <- ur.za(data$log_national, model="both")
summary(test_log_national) # fail to reject unit root null

test_diff_log_national <- ur.za(data$diff_log_national, model='intercept')
summary(test_diff_log_national) # reject unit root null

test_log_rural <- ur.za(data$log_rural, model='both')
summary(test_log_rural) # fail to reject unit root null

test_diff_log_rural <- ur.za(data$diff_log_rural,model='intercept')
summary(test_diff_log_rural) # reject unit root null


test_log_urban <- ur.za(data$log_urban, model='both')
summary(test_log_urban) # fail to reject unit root null

test_diff_log_urban <- ur.za(data$diff_log_urban, model='intercept')
summary(test_diff_log_urban) # reject unit root null

